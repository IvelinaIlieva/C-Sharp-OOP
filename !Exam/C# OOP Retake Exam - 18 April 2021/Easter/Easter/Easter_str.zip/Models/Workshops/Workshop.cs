﻿namespace Easter.Models.Workshops
{
    using System.Linq;
    using Bunnies.Contracts;
    using Contracts;
    using Eggs.Contracts;

    public class Workshop : IWorkshop
    {
        public void Color(IEgg egg, IBunny bunny)
        {
            while (bunny.Energy > 0 && bunny.Dyes.Count(d => !d.IsFinished()) > 0 && !egg.IsDone())
            {
                egg.GetColored();

                if (bunny.Dyes.ElementAt(0).IsFinished())
                {
                    bunny.Dyes.Remove(bunny.Dyes.ElementAt(0));
                }
            }
        }
    }
}
