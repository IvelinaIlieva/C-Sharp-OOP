﻿namespace WarCroft.Entities.Inventory
{
    public class Satchel : Bag
    {
        private const int InitialCapacity = 20;
        public Satchel() 
            : base(InitialCapacity)
        {
        }
    }
}
