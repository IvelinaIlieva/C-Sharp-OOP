﻿namespace WarCroft.Entities.Characters
{
    using System;
    using Constants;
    using Inventory;
    using Items;

    public abstract class Character 
    {
        private string name;
        private double health;
        private double armor;

        protected Character(string name, double baseHealth, double baseArmor, double abilityPoints, Bag bag)
        {
            Name = name;
            Health = baseHealth;
            Armor = baseArmor;
            AbilityPoints = abilityPoints;
            Bag = bag;
        }
        public string Name
        {
            get => this.name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.CharacterNameInvalid);
                }
                this.name = value;
            }
        }

        //public double BaseHealth  { get; }

        public double Health
        {
            get => this.health;
            protected internal set
                => this.health = value;
        }

       // public double BaseArmor { get; }

        public double Armor
        {
            get => this.armor;
            private set => this.armor = value;
        }

        public double AbilityPoints { get; }
        public Bag Bag { get; }

        public bool IsAlive 
            => this.Health > 0;

		protected internal void EnsureAlive()
		{
			if (!this.IsAlive)
			{
				throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
			}
		}

        public void TakeDamage(double hitPoints)
        {
            this.EnsureAlive();

            if (Armor >= hitPoints)
            {
                Armor -= hitPoints;
            }
            else
            {
                double damage = hitPoints - Armor;
                Health -= damage;
            }
        }

        public void UseItem(Item item)
        {
            this.EnsureAlive();

            item.AffectCharacter(this);
        }
    }
}