﻿namespace AquaShop.Models.Decorations
{
    public class Plant : Decoration
    {
        private const int InitialComfort = 1;
        private const decimal InitialPrice = 5;

        public Plant()
            : base(InitialComfort, InitialPrice)
        {
        }
    }
}
