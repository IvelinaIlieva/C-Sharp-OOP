﻿namespace Bakery.Core
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Contracts;
    using Models.BakedFoods.Contracts;
    using Models.Drinks.Contracts;
    using Models.Tables.Contracts;

    public class Controller : IController
    {
        private readonly List<IBakedFood> bakedFoods;
        private readonly List<IDrink> drinks;
        private readonly List<ITable> tables;

        public Controller()
        {
            this.bakedFoods = new List<IBakedFood>();
            this.drinks = new List<IDrink>();
            this.tables = new List<ITable>();
        }
        public string AddFood(string type, string name, decimal price)
        {
            throw new NotImplementedException();
        }

        public string AddDrink(string type, string name, int portion, string brand)
        {
            throw new NotImplementedException();
        }

        public string AddTable(string type, int tableNumber, int capacity)
        {
            throw new NotImplementedException();
        }

        public string ReserveTable(int numberOfPeople)
        {
            throw new NotImplementedException();
        }

        public string OrderFood(int tableNumber, string foodName)
        {
            throw new NotImplementedException();
        }

        public string OrderDrink(int tableNumber, string drinkName, string drinkBrand)
        {
            throw new NotImplementedException();
        }

        public string LeaveTable(int tableNumber)
        {
            throw new NotImplementedException();
        }

        public string GetFreeTablesInfo()
        {
            throw new NotImplementedException();
        }

        public string GetTotalIncome()
        {
            throw new NotImplementedException();
        }
    }
}
